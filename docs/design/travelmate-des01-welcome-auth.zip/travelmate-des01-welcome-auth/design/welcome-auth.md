# TravelMate — Welcome & Authentication Screens

**Issue:** DES-01 (Nasrawy1/TravelMate#3), part 1 of the MVP screens
**Owner:** Ali (UI/UX)
**Status:** Draft — visual direction chosen: Option C “Riviera”; for review by Team Leader and Frontend Developer
**Interactive design canvas:** https://claude.ai/artifact/JsJJPhffcmJByaAs3GG2E1 (shared by the owner on request)
**Design sources:** `docs/design/welcome-auth/*.dc.html`

Screens covered: Welcome / Landing, Sign in, Sign up, Forgot password (request link + set new password).
Next screens (separate spec): Trip form, AI loading, Results / itinerary, Error & empty states, Demo trip view.

---

## 1. Visual style — “Riviera” (chosen: Option C)

Direction: warm, sunny and friendly but premium — sand background, terracotta actions, Mediterranean blue text, a sun-and-sea illustration, rounded “postcard” cards. Options A–H remain on the canvas for reference.

| Token | Value | Use |
|---|---|---|
| `sand` | `#F6EBDD` | Page background, secondary buttons |
| `sand-deep` | `#EFD9C2` | Illustration panels |
| `surface` | `#FFFFFF` | Cards, form cards, inputs |
| `ink` | `#1F3A5F` | Text, “Live” label, footer |
| `muted` | `#3F5878` | Body / secondary text |
| `terracotta` | `#B14E2E` | Primary buttons, accents, focus ring (white text ≈5:1) |
| `sun` | `#E9A15A` | Illustration only |
| `sea` | `#2C5C8A` | Illustration, Demo band |
| `peach` | `#F2B98A` | DEMO badge, small highlights |
| `input-border` | `#8C8277` | Input borders (≥3:1) |
| `success` | `#2F6B4F` | Within budget, success badges, password rule met |
| `danger` | `#B3261E` | Field errors, Over budget (banner bg `#FCE8E6`, text `#8C1D18`) |
| `warning` | bg `#FDF0D2`, text `#6B4A0B` | Uncertain status |
| `button-loading` | `#7A6E64` | Disabled/loading primary button |

**Type:** Fraunces 600/800 (headings, wordmark; italic 600 for the accent word) and Figtree 400/500/700 (body, UI). Google Fonts.

**Shape & spacing:** inputs 54 px, radius 14, 1.5 px border; primary buttons 56 px, radius 16; cards radius 22–32; pills fully rounded. Hero postcards are rotated −4° / +5° with a soft navy shadow.

**Price-source labels** (keep consistent on Results): `Live` (solid ink pill, white text) · `Estimate` (dashed ink outline pill) · `Unavailable` (grey pill). Missing amounts show “—”, never $0.

**Budget status pills:** Within (green, white) · Over (red, white) · Uncertain (amber bg, dark text). They also differ in lightness.

**Icons:** inline stroke SVG, 2 px stroke, `currentColor`. No emoji.

## 2. Responsive behaviour

- Designed at 1440 px; content max-width 1200 px; side padding `clamp(16px, 4vw, 40px)`.
- Hero (text + illustration with postcards) and the auth split layout (illustrated panel + form card) use `flex-wrap` and stack below ~960 px, illustration on top.
- Card grids use `repeat(auto-fit, minmax(260px, 1fr))`.
- Top bar links wrap on narrow screens.
- Minimum touch target 44 × 44 px.

## 3. Navigation

```text
Welcome ──Create account / Start planning──> Sign up ──submit──> "Check your email"
   │                                                           └──> Sign in
   ├──Sign in──> Sign in ──success──> Trip form (next spec)
   │               ├──Forgot password?──> Reset: request link ──> "Check your email"
   │               │                         (email link) ──> Set new password ──> Sign in
   │               └──Create an account──> Sign up
   └──Explore demo trips──> Demo section (offline, no account) ──> Demo trip view (next spec)
```

Every auth screen has **Back to home** (or Back to sign in) and a link to the other auth screen. Sign in and Sign up also offer **Explore demo trips** so the offline demo is always reachable without an account (scope F-07).

## 4. Screens

### 4.1 Welcome / Landing

Sections, top to bottom:

1. **Top bar:** logo (→ Welcome), How it works (anchor), Demo trips (anchor), Sign in (outline button), Create account (primary button).
2. **Hero:** eyebrow “AI trip planner · one budget · honest prices”; H1 “Plan a whole trip around one budget.”; one-line explanation; buttons **Start planning** (→ Sign up) and **Explore demo trips** (→ demo section); “Already have an account? Sign in”.
3. **Sample trip card** (marked “Sample trip · Example only”): Istanbul → Rome, dates, nights, adults, budget; three cost rows showing each price-source label; “Budget uncertain” note. Purpose: show the honest-pricing idea before sign-up. Not live data.
4. **How it works:** 3 numbered steps — Enter your trip · We search and plan · See if it fits.
5. **Every price says where it came from:** short explanation of the price-source labels next to the sample card.
6. **Demo section** (dark band, DEMO badge): 2–3 cards, one per predefined demo trip. Placeholders `[City A → City B]`, `[Nights] · [Adults] · [Budget]` until demo trips are chosen.
7. **Footer:** “TravelMate · Graduation project” and “TravelMate plans trips. It does not book flights or hotels or take payments.”

### 4.2 Sign in

Layout: illustrated sand/sun/sea panel with “Welcome back.” (left) + white form card, max 440 px (right).

| Field | Type / autocomplete | Validation (client) | Error message |
|---|---|---|---|
| Email | `email` / `email` | required, email format | “Enter your email address.” / “Enter a valid email, like name@example.com.” |
| Password | `password` / `current-password`, show/hide toggle | required | “Enter your password.” |

Extras: **Forgot password?** link beside the Password label; “New to TravelMate? Create an account”; “or” divider; **Explore demo trips without signing in**.

States (all previewable in the canvas via Tweaks → `previewState`):

| State | Behaviour |
|---|---|
| Default | Empty fields, primary button “Sign in” |
| Field errors | Shown after submit; red border + message under each invalid field; `aria-invalid="true"` |
| Loading | Button disabled, spinner, label “Signing in…”; prevents double submit |
| Wrong credentials | Red banner “Wrong email or password — Check both and try again. Passwords are case-sensitive.” Both fields get red borders. Banner clears when the user edits a field. Do not reveal which one was wrong. |
| Success | Redirect to Trip form |

### 4.3 Sign up

Layout: same as Sign in; panel headline “Your first trip starts here.”, three benefits and “No payment details needed. We never book or charge.”

| Field | Type / autocomplete | Validation | Error message |
|---|---|---|---|
| Name | `text` / `name` | required (display name, stored in user metadata/profile) | “Enter your name.” |
| Email | `email` / `email` | required, email format | as Sign in |
| Password | `password` / `new-password`, show/hide | ≥ 8 chars, ≥ 1 letter, ≥ 1 number | live checklist under the field (grey → green ✓; red after a failed submit) |
| Confirm password | `password` / `new-password` | must match | “Re-enter your password.” / “Passwords don't match.” |

States: Default · Field errors · Loading (“Creating account…”) · **Email already registered** (red banner with “Sign in instead”) · **Check your email** (confirmation sent to `<email>`, button “Go to sign in”, “use a different email” resets the form).

> The password rule must match the Supabase Auth password policy configured by the backend (BE-02).

### 4.4 Forgot password

Single centred card under a slim top bar (logo + Back to sign in).

| Step | Content |
|---|---|
| 1. Request link | Email field + “Send reset link” (loading: “Sending link…”) |
| 2. Link sent | “If an account exists for `<email>`, you'll get a link…” — neutral wording so the screen never reveals whether an email is registered. “Back to sign in”, “Try again”. |
| 3. Set new password | Opened from the email link. New password + confirm, same rules as Sign up. |
| 4. Done | “Password updated” badge, “Go to sign in”. |

## 5. Accessibility

- Real `<label for>` on every input; errors linked with `aria-describedby`; `aria-invalid` on invalid fields.
- Error banners use `role="alert"`; success/confirmation panels use `role="status"`.
- Icon-only buttons (show/hide password) have `aria-label` that switches between “Show password” / “Hide password”.
- Visible focus ring: 3 px `#B8481A`, 2–3 px offset.
- Text contrast ≥ 4.5:1; input borders ≥ 3:1.

## 6. Notes for Frontend (Diyar) and Backend (Adel)

- Validate on submit, then live once the user edits an invalid field; the backend/Supabase stays the final authority.
- Map Supabase errors to the states above: invalid credentials → Wrong credentials banner; user already registered → Email already registered banner; email not confirmed → reuse the “Check your email” panel.
- Name is a display name only; it is not a traveller name and is not sent with trip requests.
- Sign out lives in the signed-in app header (covered with the Trip form spec).

## 7. Open questions for the Team Leader

1. Confirm Name on sign-up is wanted (scope lists only email/password).
2. Confirm the password rule (8+ chars, letter + number) with BE-02.
3. Choose the 2–3 demo trips so the placeholder cards can be filled.
4. Issues DES-01/DES-02 mention “Demo Booking / Confirmation”, but MVP scope v1.2 excludes all booking. Proposal: drop that screen; “demo” = offline sample trips.
