TravelMate - DES-01 Welcome & Auth design (Riviera style)

design/welcome-auth.md          Spec: colors, fonts, flow, fields, validation messages, states
design/welcome-auth/*.dc.html   Design source for each screen (Welcome, Login, SignUp,
                                ForgotPassword) plus style options A-H. These open in the
                                Claude design canvas, not directly in a browser.
patches/*.patch                 The 4 commits, ready to apply to the repo.

To add the commits to the repo yourself (from the TravelMate folder):
  git checkout -b des-01-welcome-auth
  git am path/to/patches/*.patch
  git push -u origin des-01-welcome-auth

Or just copy the "design" folder into TravelMate/docs/ and commit it.
