/*
 * Minimal standalone runtime for TravelMate .dc.html screens.
 * Lets the design files open directly in a browser (no Claude canvas needed).
 * Supports: {{path}} holes, <sc-if>, <sc-for>, <helmet>, event props (onClick,
 * onChange, onSubmit), data-props defaults, setState and componentDidMount.
 */
(function () {
  'use strict';

  class DCLogic {
    constructor(props) { this.props = props || {}; this.state = {}; }
    setState(patch) {
      const next = typeof patch === 'function' ? patch(this.state, this.props) : patch;
      this.state = Object.assign({}, this.state, next);
      if (this.__render) this.__schedule();
    }
    forceUpdate() { if (this.__render) this.__schedule(); }
  }
  window.DCLogic = DCLogic;

  const HOLE = /\{\{\s*([^}]+?)\s*\}\}/g;
  const WHOLE = /^\{\{\s*([^}]+?)\s*\}\}$/;

  function lookup(path, scope) {
    path = path.trim();
    if (path === 'true') return true;
    if (path === 'false') return false;
    if (path === 'null') return null;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    let v = scope;
    for (const part of path.split('.')) {
      if (v == null) return undefined;
      v = v[part];
    }
    return v;
  }

  function interpolate(str, scope) {
    return str.replace(HOLE, (_, p) => {
      const v = lookup(p, scope);
      return v == null || v === false ? '' : String(v);
    });
  }

  const EVENT_MAP = { onClick: 'click', onSubmit: 'submit', onInput: 'input', onFocus: 'focus', onBlur: 'blur', onKeyDown: 'keydown' };
  const BOOL_ATTRS = new Set(['disabled', 'checked', 'selected', 'readonly', 'required', 'hidden', 'novalidate']);

  function eventName(attr, el) {
    if (attr === 'onChange') {
      const tag = el.tagName;
      return tag === 'SELECT' || (tag === 'INPUT' && /^(checkbox|radio|date|file)$/i.test(el.type)) ? 'change' : 'input';
    }
    return EVENT_MAP[attr] || attr.slice(2).toLowerCase();
  }

  function setHandler(el, type, fn) {
    if (!el.__h) el.__h = {};
    if (!(type in el.__h)) el.addEventListener(type, (e) => { const h = el.__h[type]; if (h) h(e); });
    el.__h[type] = fn;
  }

  // Build fresh DOM nodes from the template.
  function render(tpl, scope, out) {
    for (const node of tpl.childNodes) {
      if (node.nodeType === 3) { out.push(document.createTextNode(interpolate(node.data, scope))); continue; }
      if (node.nodeType !== 1) continue;
      const tag = node.tagName.toLowerCase();
      if (tag === 'helmet') continue;
      if (tag === 'sc-if') {
        if (lookup((node.getAttribute('value') || '').replace(/^\{\{|\}\}$/g, ''), scope)) render(node, scope, out);
        continue;
      }
      if (tag === 'sc-for') {
        const list = lookup((node.getAttribute('list') || '').replace(/^\{\{|\}\}$/g, ''), scope) || [];
        const as = node.getAttribute('as') || 'item';
        list.forEach((item, i) => {
          const s = Object.create(scope); s[as] = item; s.$index = i;
          render(node, s, out);
        });
        continue;
      }
      const isSvg = node.namespaceURI === 'http://www.w3.org/2000/svg';
      const el = isSvg ? document.createElementNS(node.namespaceURI, node.tagName) : document.createElement(node.tagName);
      const deferred = [];
      for (const { name, value } of Array.from(node.attributes)) {
        if (name.startsWith('hint-')) continue;
        const whole = value.match(WHOLE);
        const reactName = node.getAttributeNames ? name : name;
        if (/^on[a-z]/.test(name)) {
          // attribute names are lowercased by the parser; recover the camelCase form
          const camel = 'on' + name.charAt(2).toUpperCase() + name.slice(3);
          const fn = whole ? lookup(whole[1], scope) : null;
          if (typeof fn === 'function') deferred.push([camel, fn]);
          continue;
        }
        let v = whole ? lookup(whole[1], scope) : interpolate(value, scope);
        if (BOOL_ATTRS.has(name)) {
          if (v === true || v === '' || v === name || v === 'true') el.setAttribute(name, '');
          continue;
        }
        if (name === 'value' && !isSvg) { el.__value = v == null ? '' : String(v); continue; }
        if (v == null || v === false) continue;
        el.setAttribute(reactName, String(v));
      }
      render(node.content || node, scope, (kids => { el.__kids = kids; return kids; })([]));
      for (const k of el.__kids) el.appendChild(k);
      delete el.__kids;
      for (const [camel, fn] of deferred) setHandler(el, eventName(camel, el), fn);
      if (el.__value !== undefined) el.value = el.__value;
      out.push(el);
    }
    return out;
  }

  // Patch the live DOM to match freshly rendered nodes, keeping focus and input state.
  function patchChildren(parent, fresh) {
    const old = Array.from(parent.childNodes);
    fresh.forEach((n, i) => {
      const o = old[i];
      if (!o) { parent.appendChild(n); return; }
      if (o.nodeType !== n.nodeType || (o.nodeType === 1 && o.tagName !== n.tagName)) { parent.replaceChild(n, o); return; }
      if (o.nodeType === 3) { if (o.data !== n.data) o.data = n.data; return; }
      for (const a of Array.from(o.attributes)) if (!n.hasAttribute(a.name)) o.removeAttribute(a.name);
      for (const a of Array.from(n.attributes)) if (o.getAttribute(a.name) !== a.value) o.setAttribute(a.name, a.value);
      if (n.__h) for (const t in n.__h) setHandler(o, t, n.__h[t]);
      if (o.__h) for (const t in o.__h) if (!n.__h || !(t in n.__h)) o.__h[t] = null;
      patchChildren(o, Array.from(n.childNodes));
      if (n.__value !== undefined && o.value !== n.__value) o.value = n.__value;
    });
    for (let i = old.length - 1; i >= fresh.length; i--) parent.removeChild(old[i]);
  }

  function boot() {
    const host = document.querySelector('x-dc');
    const script = document.querySelector('script[data-dc-script]');
    if (!host || !script) return;

    // Template: keep a detached copy of the authored markup.
    const tpl = document.createElement('div');
    tpl.innerHTML = host.innerHTML;
    const helmet = tpl.querySelector('helmet');
    if (helmet) for (const n of Array.from(helmet.children)) document.head.appendChild(n.cloneNode(true));

    // Props: defaults from data-props.
    const props = {};
    try {
      const decl = JSON.parse(script.getAttribute('data-props') || '{}');
      for (const k in decl) if (k[0] !== '$' && decl[k] && 'default' in decl[k]) props[k] = decl[k].default;
    } catch (e) { console.warn('data-props parse failed', e); }
    const q = new URLSearchParams(window.__TM_QUERY != null ? window.__TM_QUERY : location.search);
    q.forEach((v, k) => { props[k] = v; });

    const Component = new Function('DCLogic', script.textContent + '\nreturn Component;')(DCLogic);
    const inst = new Component(props);
    inst.props = props;
    if (!inst.state) inst.state = {};

    host.innerHTML = '';
    host.style.display = 'contents';
    let queued = false;
    inst.__render = () => { patchChildren(host, render(tpl, inst.renderVals ? inst.renderVals() : {}, [])); };
    inst.__schedule = () => { if (!queued) { queued = true; requestAnimationFrame(() => { queued = false; inst.__render(); }); } };
    inst.__render();
    if (inst.componentDidMount) inst.componentDidMount();
    window.addEventListener('beforeunload', () => inst.componentWillUnmount && inst.componentWillUnmount());
  }

  const hide = document.createElement('style');
  hide.textContent = 'x-dc:not([data-ready]){visibility:hidden}';
  document.head.appendChild(hide);
  const ready = () => { boot(); const h = document.querySelector('x-dc'); if (h) h.setAttribute('data-ready', ''); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
  else ready();
})();
