# TravelMate — UI/UX Design Spec (handoff)

**Issues:** DES-02 Design Core MVP Screens & States (Nasrawy1/TravelMate#6) · builds on DES-01 (Nasrawy1/TravelMate#3, closed)
**Owner:** Ali (UI/UX) · **For:** Diyar (FE-02 #16, FE-03), Adel (BE-03/BE-04), Ziyad, Nasrawy (review)
**Contract:** API contract **v0.4 review candidate** (`docs/api-contracts.md`, `docs/contracts/api-v0.4.schema.json`, `docs/fixtures/`). v0.4 is not yet approved (PLAN-02 #11); anything that changes there must be re-checked here.
**Style:** “Riviera” (option C of eight explored)
**Scope rules followed:** no booking, checkout, payment or booking-confirmation screens; **no saved-trip screens** (F-09 deferred); generation never persists a trip.

---

## 0. What is in this folder

| Path | What it is |
|---|---|
| `TravelMate-design.html` | **Everything in one file**: every screen with a Desktop/Phone switch and a state picker, this spec, and the tokens. Easiest to send and open |
| `SPEC.md` | This document: behaviour, copy, validation, states and contract mapping |
| `screens/index.html` | Clickable prototype of every screen (open in a browser) |
| `screens/*.dc.html` | One file per screen; markup + inline styles + a small logic class showing each state |
| `screens/support.js` | Tiny runtime so the `.dc.html` files run in a normal browser. Not app code |
| `screens/Option*.dc.html` | The eight style options explored before Riviera was chosen (reference only) |
| `tokens/tokens.css`, `tokens/tokens.json` | Design tokens (`--tm-*`) for the React app |
| `screenshots/` | Every screen at desktop (1440 px) and phone (390 px) |

**State previews** (query string on a screen, or the State picker in `TravelMate-design.html`):
`Login.dc.html?previewState=wrongCredentials` · `SignUp.dc.html?previewState=emailTaken` · `ForgotPassword.dc.html?previewState=setNewPassword` ·
`TripForm.dc.html?previewState=unsupportedLocation` · `Generating.dc.html?previewState=rateLimited` ·
`Results.dc.html?fixture=known-minimum-over-budget` · `DemoTrip.dc.html?trip=barcelona`. All values are listed in §5.

**Your trip (`Results.dc.html`) renders the real v0.4 fixture files** from `docs/fixtures/` (within-budget, over-budget, partial-prices, no-prices, known-minimum-over-budget, unknown-taxes). The three demo trips are new contract-shaped data that pass the team's own `validate_fixtures.py` checks. Login, sign-up and generation are not connected in the prototype.

---

## 1. Screens, routes and navigation

Routes follow Diyar's FE-01 router (PR #14).

| # | Screen | File | Route | Signed in? |
|---|---|---|---|---|
| 1 | Welcome / landing | `Main.dc.html` | `/` | No |
| 2 | Sign up | `SignUp.dc.html` | `/signup` | No |
| 3 | Sign in | `Login.dc.html` | `/login` | No |
| 4 | Forgot password (request, sent) | `ForgotPassword.dc.html` | `/forgot-password` | No |
| 4b | Set new password (from email link), done | `ForgotPassword.dc.html` (`setNewPassword`, `passwordUpdated`) | `/reset-password` | Recovery session |
| 5 | Plan a trip | `TripForm.dc.html` | `/trip-planner` | **Yes** |
| 6 | Building your trip (loading + errors) | `Generating.dc.html` | `/trip-planner` (in-page state) or `/results` while pending | **Yes** |
| 7 | Your trip (results) | `Results.dc.html` | `/results` | **Yes** |
| 8 | Demo trip (offline, 3 samples) | `DemoTrip.dc.html` | `/offline-demo` | **No** (no hosted sign-in, no API calls) |
| – | Page not found | `NotFound.dc.html` | `*` | Either |
| – | Error & empty states (reference) | `States.dc.html` | – | – |
| – | Component library (reference) | `Components.dc.html` | – | – |

```text
Welcome ──Get started / Plan my trip──> Sign up ──submit──> Check your email ──> Sign in
   │                                                                              │
   ├──Sign in─────────────────────────────────────────────────────────────────────┤
   │                          Sign in ──Forgot password?──> Request link ──email──> Set new password ──> Sign in
   │                                                                              ▼
   │                         Plan a trip ──Generate my trip──> Building your trip ──See my trip──> Your trip
   │                              ▲                                   │ error: Try again / Edit trip / Sign in
   │                              └──────────── Edit trip ────────────┴───────────────────────────────┘
   └──See a demo / demo cards──> Demo trip (also from Sign in, Sign up and the 503 error) ──Create account──> Sign up
```

- Signed-in screens redirect to `/login` without a session; `/login` and `/signup` redirect to `/trip-planner` with one.
- The demo is an explicit separate path (contract §6): it must not initialise Supabase or call FastAPI.
- The signed-in header has **Plan a trip · avatar initial + name · Sign out** only (no “My trips”: F-09 deferred).

---

## 2. Visual style (tokens)

All values are in `tokens/tokens.css`. Use the variables, not raw hex values.

| Token | Hex | Use |
|---|---|---|
| `--tm-sand` | `#F6EBDD` | Page background, secondary buttons |
| `--tm-sand-deep` | `#EFD9C2` | Illustration panels |
| `--tm-surface` | `#FFFFFF` | Cards, inputs |
| `--tm-ink` | `#1F3A5F` | Text, “Live” label, navy panels |
| `--tm-muted` | `#3F5878` | Secondary text |
| `--tm-terracotta` | `#B14E2E` | Primary buttons, “Selected” badge and ring, focus ring (white text ≈ 5:1) |
| `--tm-sun` / `--tm-sea` | `#E9A15A` / `#2C5C8A` | Illustration only (sea also for the demo band) |
| `--tm-peach` | `#F2B98A` | DEMO ribbon, “Demo price” label |
| `--tm-line` | `#EADFD1` | Dividers, card borders |
| `--tm-input-border` | `#8C8277` | Input borders (≥ 3:1) |
| `--tm-success` | `#2F6B4F` | Within budget, done, “Taxes and fees included” |
| `--tm-danger` / `--tm-danger-bg` / `--tm-danger-text` | `#B3261E` / `#FCE8E6` / `#8C1D18` | Errors, Over budget, Missing chips, “Unknown” amounts |
| `--tm-warning-bg` / `--tm-warning-text` | `#FDF0D2` / `#6B4A0B` | Uncertain, warnings, MOCK ribbon |
| `--tm-unavailable-bg` / `--tm-unavailable-text` | `#E2DACE` / `#4F5B66` | “Unavailable” and “Unknown” labels |
| `--tm-disabled` | `#7A6E64` | Loading / disabled primary button |

**Type:** Fraunces 600/800 (headings, prices) + Figtree 400/500/700. Scale: Display 48–88 · H1 36–56 · H2 32 · H3 22 · Body L 18 · Body 16 · Label 15 bold · Small 14 · Eyebrow 13 bold caps.
**Shape:** fields 54 px, radius 14 · buttons 56 px, radius 16 · cards 24 · panels 28 · pills 999. Spacing 4/8/12/16/24/32/48/64. Page max 1240 px; side padding `clamp(16px, 4vw, 48px)`.
**Money:** always two decimals and a thousands separator (`$1,140.00`, contract §2). Estimates start with `~`. Unknown shows the word **Unknown** or “—”, never `$0.00`. An explicit `0` estimate (a free activity) shows `$0.00` with the Estimate label.
**Times:** offer timestamps are UTC in the contract; show them as `Tue, 10 Nov, 07:00 UTC` until local times are available (see §10).

---

## 3. Components (see `Components.dc.html`)

| Component | Variants / states | Notes |
|---|---|---|
| Button | Primary · Secondary · On-sand · Outline/White on navy · Loading (disabled + spinner) · Countdown-disabled (“Try again in 30 s”) | Min 44 px. Loading disables to prevent duplicate generation |
| Text / select / date / money field, stepper | Default · Filled · Focus · Error (red border + message) | Label above; `aria-describedby` → error |
| Rule pills, night counter | Not met · Met · Failed / OK · Out of range | |
| Price label | `Live` · `Estimate` (dashed) · `Unavailable` · `Unknown` · `Demo price` | Exactly one per amount |
| Budget status pill | Within budget · Over budget · Uncertain | Always with a one-sentence reason |
| Ribbon | **DEMO** (peach, demo path) · **MOCK** (amber, online screens showing fixture data) | Required by FE-02/contract §6 |
| Banner | Error (`role="alert"`) · Warning (`role="status"`) · Info | |
| Offer card | Flight / hotel · **Selected** (terracotta ring + badge) · alternative · Unavailable | Highlights the backend's selection only |
| Day card | Day N + full date · ordered activities · empty-day reason | No AI day title in v0.4 |
| Expense row | Label · kind label · amount · basis text | Grouped by category |
| Progress step | Done · Active · Waiting | Client-side only |

---

## 4. Responsive behaviour

- Built at 1440 px; checked at 390 px. No horizontal scrolling.
- Two-column layouts stack below **~960 px**. On Your trip and Demo trip the **budget and expenses column moves above** the offers and itinerary.
- The decorative sun in the trip banner is hidden below 600 px so the title stays readable.
- Headings scale with `clamp()`; body text never below 14 px. Top bars wrap onto two rows on phones.

---

## 5. Screens in detail

Client validation runs on submit, then live as the user fixes a field. FastAPI is the final authority (contract §3/§5).

### 5.1 Welcome (`/`)
Top bar · hero (“Sun, sea and a plan that *fits.*”, Plan my trip, See a demo) with illustrative postcards · How it works · price-label explainer · demo band with three cards (Istanbul → Rome · London → Paris · Dubai → Barcelona → `/offline-demo`) · footer. Postcard numbers are marketing samples.

### 5.2–5.4 Sign up, Sign in, Forgot / reset password
Unchanged from DES-01 and **already implemented in PR #14**. Fields, messages and states are as built (Name, Email, Password with live rules, Confirm; wrong-credentials banner; neutral “If an account exists…” reset copy). Auth integration and email confirmation are tracked in BE-02 #8.

### 5.5 Plan a trip (`/trip-planner`)

| UI field | Request field (v0.4) | Rule | Client error |
|---|---|---|---|
| From (select) | `departure_city` | canonical supported label | “Choose where you leave from.” |
| To (select) + swap | `destination_city` | supported, ≠ departure | “Choose your destination.” / “Pick a different city from your departure.” |
| Start date | `start_date` (YYYY-MM-DD) | after **today's UTC date** | “Choose a start date.” / “Start date must be in the future.” |
| Return date | `return_date` | 1–7 nights after start | “Choose a return date.” / “Return date must be after the start date.” / “Trips can be up to 7 nights.” |
| Stay (read-only) | – | green 1–7, red otherwise | – |
| Adults stepper | `adults` (integer) | 1–4 | helper “1–4 adults. Children aren't supported yet.” |
| Budget (USD) | `budget_usd` (number) | > 0, whole trip, all adults | “Enter your total budget.” / “Budget must be more than $0.00.” |

- No currency selector, one-way switch or user id (contract §3).
- **City list:** the prototype's six cities are labelled “Sample cities for testing (mock)” until provider coverage is verified (FE-02).
- Summary when valid: “Istanbul → Rome · 5 nights · 2 adults · $1,500.00”.
- **Server errors on this screen:** `400 UNSUPPORTED_LOCATION` → banner “We can't price this route yet”; `400 INVALID_TRIP_DATES` → “Check your dates”; `422 VALIDATION_ERROR` → banner + each `details.fields[]` message under the matching field.
- While the request is in flight the button is disabled and reads “Sending…”; a second submit is impossible.
- States: `live` · `errors` · `filled` · `submitting` · `unsupportedLocation` · `invalidDates` · `serverValidation`.

### 5.6 Building your trip (loading and request errors)
Five steps advance on a timer (the API returns one response; there are no progress events). When the response arrives: success → **See my trip**; error → the matching panel:

| HTTP / code (v0.4) | Title | Actions |
|---|---|---|
| 502 `AI_GENERATION_FAILED` | We couldn't build your plan | Try again · Edit trip |
| 504 `GENERATION_TIMEOUT` | This is taking too long | Try again · Edit trip |
| 429 `RATE_LIMITED` | Too many requests right now | Try again (disabled until `Retry-After`, e.g. “Try again in 30 s”) · Edit trip |
| 503 `PROVIDER_UNAVAILABLE` | The planning service is unavailable | Try again · Edit trip · Open a demo trip |
| 500 `INTERNAL_ERROR` | Something went wrong on our side | Try again · Edit trip |
| 401 `UNAUTHORIZED` | Please sign in again | Sign in · Edit trip |

Each panel shows `code · Reference {request_id}` in small text. Never auto-retry generation (contract §5). Frontend transport allowance is 70 s.
States: `live` · `searching` · `done` · `aiFailed` · `timeout` · `rateLimited` · `providerUnavailable` · `internalError` · `unauthorized`.

### 5.7 Your trip (`/results`) — contract mapping

States = the six v0.4 fixtures (`?fixture=`): `within-budget` · `over-budget` · `partial-prices` · `no-prices` · `known-minimum-over-budget` · `unknown-taxes`. Toggle the MOCK ribbon with `fixtureBanner`.

| Screen element | v0.4 field(s) | Display rule |
|---|---|---|
| MOCK ribbon | fixture `manifest.data_mode = structural_mock` | Shown whenever fixture data is rendered online; never for real API data |
| Banner: route | `trip.departure_city`, `trip.destination_city` | “Istanbul → *Rome*” |
| Banner: meta | `trip.start_date`, `return_date`, `nights`, `adults`, `budget.budget_usd` | “10 – 12 November 2026 · 2 nights · 2 adults · Budget $1,500.00” |
| “No live prices” banner | `live_integration_status = no_price` | With Try again |
| Warnings list | `warnings[].code`, `.message` | Short title per known code + API message; unknown codes show “Note.” + message |
| Flights block | `travel_options.flights.status`, `.offers[]` | `live` → offer cards; `unavailable` → “—” card |
| Flight card | `airline`, `departure_airport_code` → `arrival_airport_code`, `outbound_departure_at`, `return_departure_at`, `adults`, `price.amount_usd`, `taxes`, `source`, `retrieved_at` | Coverage “Total for N adults” |
| Hotel card | `name`, `area` (null → “Area not provided”), `check_in`, `check_out`, `occupancy_adults`, `room_qty` (null → “rooms not provided”), `price`, `taxes`, `source`, `retrieved_at` | Coverage “Total stay, N adults” |
| Selected offer | `budget.selected_flight_offer_id`, `selected_hotel_offer_id` | Terracotta ring + “Selected”, listed first; the UI never chooses |
| Taxes line | `taxes.status` / `additional_amount_usd` | included → “Taxes and fees included” (green) · additional_known → “+ $50.00 taxes and fees (added in the budget)” · unknown → “Taxes and fees unknown” (red) |
| Price label | `price.kind = provider` | `Live` (online) / `Demo price` (demo) |
| Day card | `itinerary[]` (`date`) | “Day N” + “Tuesday 10 November”; exactly nights + 1 days |
| Activity row | `activities[].order`, `name`, `area`, `description`, `cost` | Numbered by `order`; cost: estimate → “~$40.00”/“$0.00” + Estimate; unknown → “Unknown” |
| Empty day | `empty_day_reason` (first/last day only) | Sand box with the reason text |
| Budget check status | `budget.status` | Within/Over/Uncertain pill + reason (see below) |
| Budget rows | `budget_usd`, `provider_subtotal_usd`, `estimated_subtotal_usd`, `projected_total_usd` | “Live prices”, “Estimates (~)”, projected total or “Not calculable” when null |
| Missing chips | `budget.missing_categories[]` | Flights, Hotel, Taxes and fees, Activities, Food, Local transport |
| Notes | `budget.notes[]` | Small text under the totals |
| Itemized expenses | `budget.cost_items[]` (`category`, `label`, `amount_usd`, `kind`, `basis`, `source_offer_id`, `activity_ref`) | Grouped: Flights · Hotel · Taxes and fees · Activities · Food · Local transport; each row shows a readable label, kind label, amount (or Unknown) and `basis` |

**Status reasons:** within → “The projected total fits your budget. Prices can still change.” · over with total → “The projected total is $X over your budget.” · over with total null (known minimum) → “Live prices alone already exceed your budget, before the missing costs are added.” · uncertain → “Some costs are unknown, so we can't say whether this trip fits your budget.”
**Footnote:** “An estimate, not a booking price. Totals are calculated by TravelMate, not by the AI.” The UI never recalculates totals or status; it renders the backend values.

### 5.8 Demo trip (`/offline-demo`)
Peach **DEMO** ribbon (“Sample trip for preview. Prices are examples, not live, and nothing is sent or saved.”), header **Exit demo · Create account**, a picker of three trips, then **the same results components** as §5.7 with `Demo price` instead of `Live` and “Sample data” as the source.

| Demo | Route | Nights · adults · budget | Result |
|---|---|---|---|
| `rome` | Istanbul → Rome | 3 · 2 · $1,200.00 | Within budget (~$1,184.00); two flight offers; the lowest total including fees is selected; last day is an empty travel day |
| `paris` | London → Paris | 2 · 1 · $600.00 | Over budget (~$670.00) |
| `barcelona` | Dubai → Barcelona | 4 · 3 · $2,500.00 | Uncertain: hotel unavailable, flight taxes unknown; 3 warnings |

Data is contract-shaped, validated with `docs/contracts/validate_fixtures.py` rules, and works offline. The final 2–3 curated journeys belong to FE-03.

### 5.9 Page not found (`*`)
Illustration, “ERROR 404”, “We can't find that page”, Go to home · Plan a trip.

---

## 6. Error and empty states (`States.dc.html`)

| # | Situation | Source | Where |
|---|---|---|---|
| 1 | No live flight or hotel prices | `live_integration_status = no_price` | Your trip |
| 2 | Route not covered | 400 `UNSUPPORTED_LOCATION` | Plan a trip |
| 3 | Offline | browser network | Banner, any screen |
| 4 | Too many requests | 429 `RATE_LIMITED` + `Retry-After` | Building your trip |
| 5 | Session expired | 401 `UNAUTHORIZED` | Any signed-in screen |
| 6 | Unrecognised warning code | `warnings[]` | Your trip |
| 7 | Day without activities | `empty_day_reason` | Itinerary |
| 8 | Unknown activity cost | `cost.kind = unknown` | Itinerary row |
| – | AI failure, timeout, provider down, internal error | 502 / 504 / 503 / 500 | Building your trip (§5.6) |
| – | Invalid dates, field errors | 400 `INVALID_TRIP_DATES`, 422 `VALIDATION_ERROR` | Plan a trip (§5.5) |

---

## 7. Accessibility

Labels on every field; errors via `aria-describedby` and `aria-invalid`; error banners `role="alert"`, progress and warnings `role="status"`; icon-only buttons have `aria-label`; toggles use `aria-pressed`; selected offers say “selected” in their accessible name; visible 3 px focus ring; contrast ≥ 4.5:1 text, ≥ 3:1 borders; status always written in words; touch targets ≥ 44 px; one `<h1>` per screen; spinner animation stops under `prefers-reduced-motion`.

## 8. Copy rules

Plain and short; sentence-case buttons; money per §2; never promise a booking or guaranteed price; never present AI or demo prices as live.

---

## 9. Checks done

- **Prototype:** every screen at 1440 px and 390 px in Chromium: no script errors, no unfilled placeholders, no horizontal overflow, labelled fields, named buttons, one `<h1>`; click-through flows for sign-up, sign-in, trip form, loading, retry and errors.
- **Contract data:** all six response fixtures render with exactly the backend's subtotals, totals, status and missing categories; no unknown amount is shown as $0.00; the demo trips pass the team's `validate_fixtures.py` rules.
- **Frontend PR #14 (main, 16 Oct):** `npm run build` (typecheck + Vite) passes; all routes load with no console errors, no horizontal overflow at 390 px, all fields labelled; sign-in/sign-up/forgot forms show the designed validation messages and honest “not connected yet” messages. See §11.

---

## 10. Open questions and flagged contract items (for Nasrawy)

**Contract v0.4 — please confirm or change:**
1. **No day title and no time of day.** v0.4 activities have only `order`; the design numbers them and titles each day with its date. Add an optional `title`/`time_of_day` if wanted.
2. **`cost_items.label` is machine-like in fixtures** (`activity-2026-11-10`, `hotel-tax`). The contract says “user-readable”; until then the UI builds labels from category + activity name. Please make labels readable or confirm the UI rule.
3. **Times are UTC only.** Flight times show “07:00 UTC”; travellers expect local airport time. Consider adding local times or the airport timezone.
4. **Food and local transport** stay **Unknown** in real output until the estimation policy is approved (fixtures show example estimates).
5. **Supported cities and provider names** are still pending; the form shows a mock list.

**Scope / product:**
6. Keep the **Name** field on sign-up? (Scope lists traveller names as not collected; it is an account display name only. Already built in PR #14.)
7. Confirm the **password rule** (8+ chars, a letter, a number) with BE-01/BE-02 Supabase settings.
8. Confirm the **2–3 demo journeys** (FE-03); the three here are proposals.

---

## 11. Review of the built Welcome/Auth screens (PR #14)

The implementation matches the design closely (layout, copy, colours, states). Only small, intentional differences remain:

| Screen | Difference | Suggestion |
|---|---|---|
| Welcome | Demo cards still show `[City A → City B]` placeholders | Use the three demo trips (§5.8) when FE-03 starts |
| Sign in / Sign up | Demo button reads “Demo trips are coming soon.” | Link to `/offline-demo` once FE-03 lands |
| Signed-in pages | Placeholder pages show a developer navigation bar | Replace with the signed-in header (§1) in FE-02 |
| Not found | Placeholder text | Use §5.9 |

No errors were found in the built screens.
