# TravelMate design source (DES-02)

Riviera design for TravelMate: every screen, state, token and the handoff spec.

## Start here
1. `SPEC.md` — routes, screens, field mapping to API contract v0.4, error codes, responsive rules, open questions.
2. `tokens/tokens.css` — CSS variables (colours, fonts, radii, spacing). Copy into `frontend/src/styles/`.
   `tokens/tokens.json` — the same values as JSON.
3. `screenshots/` — desktop (1440 px) and phone (390 px) image of every screen.
4. `screens/` — the screen source files.

## Screen source files
Each `*.dc.html` file is one screen: HTML markup with inline styles plus a small
script at the bottom with the screen's logic and states. Open `screens/index.html`
in a browser (double-click, no server needed) to click through them.

| File | Route | What it shows |
|---|---|---|
| Main.dc.html | `/` | Welcome / landing |
| Login.dc.html | `/login` | Sign in, errors, loading, success |
| SignUp.dc.html | `/signup` | Sign up, password rules, email taken |
| ForgotPassword.dc.html | `/forgot-password` | 4-step password reset |
| TripForm.dc.html | `/trip-planner` | Trip form, live validation, 400/422 |
| Generating.dc.html | (loading) | Loading steps, 401/429/500/502/503/504 panels |
| Results.dc.html | `/results` | Itinerary, offers, budget, all 6 v0.4 fixtures |
| DemoTrip.dc.html | `/offline-demo` | Offline demo, 3 sample trips, DEMO ribbon |
| States.dc.html | — | Error and empty states board |
| NotFound.dc.html | `*` | 404 |
| Components.dc.html | — | Buttons, inputs, cards, badges |

`support.js` is only the small runtime that lets these files run in a browser;
it is not meant to be copied into the React app.

To see a specific state, add it to the address, e.g.
`Results.dc.html?fixture=over-budget` or `Login.dc.html?previewState=errors`.

## Rules to keep (details in SPEC.md)
- Render backend values as given: selected offer IDs, totals and budget status are never recalculated.
- Unknown amounts show "Unknown", never $0.00. Money always has two decimals.
- Fixture data shows the MOCK banner; demo data shows the DEMO ribbon.
- Layouts stack below 960 px; no horizontal scroll at 390 px.
- No booking, payment or saved-trip screens.
